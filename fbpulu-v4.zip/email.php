<?php
$mailto = "royadiryi@gmail.com"; // Ganti dengan alamat Email lo.
?>
